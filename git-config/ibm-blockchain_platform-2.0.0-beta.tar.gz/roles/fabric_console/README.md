# console

This role installs the [Hyperledger Fabric Operations Console](https://github.com/hyperledger-labs/fabric-operations-console)

## Documentation

Documentation for this Ansible collection is available here: https://ibm-blockchain.github.io/ansible-collection/

The documentation includes installation instructions, tutorials, and reference material for all modules and roles in this collection.

## License

Apache-2.0

## Author Information

This Ansible collection is maintained by the IBM Hyperledger Fabric Support Offering development team.