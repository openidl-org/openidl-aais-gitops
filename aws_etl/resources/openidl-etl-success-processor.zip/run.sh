AWS_PROFILE=nd node ./idm.js #test idm
#AWS_PROFILE=nd node ./dynamo.js #test dynamo
#AWS_PROFILE=nd node ./index.js #run lambda
#AWS_PROFILE=nd node ./s3.js #test s3
