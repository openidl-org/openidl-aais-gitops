# openidl-etl-success-processor

This project is meant to run as a lambda.

## build

change directory to the openidl-etl-success-processor directory

`zip -r function.zip .`
