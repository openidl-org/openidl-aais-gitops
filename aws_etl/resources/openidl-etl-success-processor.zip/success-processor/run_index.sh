#AWS_PROFILE=nd node ./index.js
AWS_PROFILE=nd node ./s3.js
