aws s3 rm s3://aais-dev-openidl-etl-idm-loader-bucket/sample-data-9001.json --profile nd

