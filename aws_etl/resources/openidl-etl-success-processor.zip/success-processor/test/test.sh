cd ..;
./compile.sh;
cd test;
./zip.sh;
./delete.sh;
./trigger.sh
