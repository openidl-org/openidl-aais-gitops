AWS_PROFILE=nd node ./dynamo.js
