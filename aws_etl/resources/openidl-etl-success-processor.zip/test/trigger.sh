./delete.sh
aws s3 cp ./sample-data-9001.json s3://aais-dev-openidl-etl-idm-loader-bucket/sample-data-9001.json --profile nd
