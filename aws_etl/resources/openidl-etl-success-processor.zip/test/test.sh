cd ..;
./zip.sh;
cd test;
./deploy.sh;

