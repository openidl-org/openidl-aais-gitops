aws s3 rm s3://aais-dev-openidl-etl-intake-bucket/sample05.csv --profile nd
aws s3 cp ./sample05.csv s3://aais-dev-openidl-etl-intake-bucket/sample06.csv --profile nd